<?php

$conn = mysqli_connect('localhost','root','','your_contact_book');


?>